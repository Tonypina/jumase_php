<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correo de Contacto</title>
</head>
<body>
    <h1>Correo Electrónico</h1>
    <p><strong>Nombre: </strong><?php echo e($contacto['name']); ?> <?php echo e($contacto['lname']); ?></p>
    <p><strong>Correo: </strong><?php echo e($contacto['email']); ?></p>
    <p><strong>Asunto: </strong><?php echo e($contacto['subject']); ?></p>
    <p><strong>Cuerpo: </strong><?php echo e($contacto['body']); ?></p>
</body>
</html><?php /**PATH /home/jumaseco/public_html/resources/views/email/correo.blade.php ENDPATH**/ ?>